<table bgcolor="white" align="center" width="100%" height="100%" border="0" cellspacing="7">
	<tr height="100">
		<td >
			<h1 align="center">Welcome to our site</h1>
		</td>
	</tr>
</table>