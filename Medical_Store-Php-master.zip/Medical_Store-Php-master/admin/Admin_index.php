

<table width="70%" cellspacing="0" cellpadding="10" border="1" align="center">
    <tr>
        <td colspan="2" valign="middle" height="70">
            <table width="100%">
                <tr>
                    <td>
                        <a href="./dashboard.html" target="contentFrame">
                            <img alt="SHEBA" width="100" height="80" src="Capture.png">
                        </a>
                    </td>
                    <td align="right">
                        Logged in as <a href="Admin_profile.html" target="contentFrame">Admin</a>&nbsp;|
                        <a href="../web_index.html">Logout</a>
                    </td>
                </tr>
            </table>
        </td>
    </tr>
    <tr>
        <td width="200" valign="top">
        	<font size="4">
        	<ul>
        	<li><a href="./dashboard.html" target="contentFrame">Dashboard</a></li><br>
            <li><a href="../app/add_delete_meds.php" target="contentFrame"><label>Medicine Management</label></a></li><br>
            <li><a href="../app/add_delete_products.php" target="contentFrame"><label>Add Other Products</label></a></li><br>
		<li><a href="../app/donor_info.php" target="contentFrame"><label>Donor Informations</label></a></li>

        	</ul>
        </font>
        </td>
        <td valign="top">
            <iframe name="contentFrame" frameborder="0" width="100%" height="530" src="./dashboard.html"></iframe>
        </td>
    </tr>
    <tr>
        <td colspan="2" align="center">
            Copyright &copy; 2017
        </td>
    </tr>
</table>
