<!DOCTYPE html>
<html>
		<head>
			<title>add/delete product</title>
		</head>
		<body>
		<table width="100%" height = "100%" align="center" cellspacing="1" cellpadding="10" border="1" bgcolor="black">
		      
			<tr bgcolor="white" align="center">
				     <td heaight="200" colspan="3">
					 <p><h3>Add/Delete Product from DB</p><hr></h3>
	          <ul align="left">
	            	<li><a href="add_product.php">Add Product</a></li>
	            	<li><a href="retrieve_product.php">Retrieve</a></li>
	            </ul>
	             
	       </tr>
	       	<tr bgcolor="white" align="center"><td colspan="3"><a href="../admin/dashboard.html">Back</a></td></tr>
		</table>
		</body>
</html>