<?php
	echo "<script>
				alert('you need to login first !!!');
				document.location='../interface.html';
			 </script>";
			 ?>