# Medical_Store
An online Medical Store which will provide people with medicines, various medical informations and some other facilities .
